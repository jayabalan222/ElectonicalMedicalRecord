package com.cts.admin.dao;

import com.cts.admin.model.Admin;

public interface AdminDAO {
  public int adminlogin(Admin a);
}

