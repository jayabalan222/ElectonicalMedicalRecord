package com.cts.admin.bo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.admin.dao.AdminDAOImp;
import com.cts.admin.model.Admin;


@WebServlet("/AdminLoginValidation")
public class AdminLogin extends HttpServlet {
                private static final long serialVersionUID = 1L;

     
    public AdminLogin() {
        
    }

                
                protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                                PrintWriter out=response.getWriter();
                                  response.setContentType("text/html");
                                  out.println("<html><head><title>Invalid</title></head><body><center>");
                                  try
                                  {
                                                String uname=request.getParameter("uname");
                                                String password=request.getParameter("password");
                                                Admin a=new Admin(uname, password);
                                                AdminDAOImp ado=new AdminDAOImp();
                                                int result=ado.adminlogin(a);
                                                if(result==1)
                                                {
                                                                HttpSession s=request.getSession(true);
                                                                s.setAttribute("ref",uname);
                                                                RequestDispatcher rd=request.getRequestDispatcher("adminhome.jsp");
                                                                rd.forward(request, response);
                                                }
                                                else
                                                {
                                                                RequestDispatcher rd=request.getRequestDispatcher("adminlogin.jsp");
                                                                out.println("<font color ='red'>Uname or Password is Incorrect</font>");
                                                                rd.include(request, response);
                                                }
                }
                                  catch(Exception e)
                                  {
                                                  System.out.println(e);
                                  }
                                  out.println("</center></body></html>");

}}
