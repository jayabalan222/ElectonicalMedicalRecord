package com.cts.patient.dao;

import java.sql.PreparedStatement;

import com.cts.patient.model.PatientRegister;
import com.cts.util.Db;

public class AddPatientDAOImp implements AddPatientDAO{

	@Override
	public int addpatient(PatientRegister p) {
		int result=0;
        PreparedStatement pst=null;
        PreparedStatement pst1=null;
        try
        {
        	pst = Db.getDb().prepareStatement("insert into patient(FirstName,LastName,Age,Gender,ContactNumber,Password) values('"+ p.getFirstName()+"','"+p.getLastName()+"','"
        +p.getAge()+"','"+p.getGender()+"','"+p.getContactNumber()+"','"+p.getPassword()+"');");
        	pst1=Db.getDb().prepareStatement("insert into patientlogin(Password) values('"+p.getPassword()+"');");
        	result=pst.executeUpdate();
        	result=pst1.executeUpdate();
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }
		return result;
	}
   
}
